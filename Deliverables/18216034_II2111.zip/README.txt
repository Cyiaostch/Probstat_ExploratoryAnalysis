Deryan Tejasatya Lubis
18216034
Sistem dan Teknologi Informasi

Script program yang digunakan ada pada folder Script

Karena saya menggunakan jupyter notebook, saya juga menyertakan notebooknya

File Excel data pada folder Data(Excel)

Folder Histogram berisi plot2 histogram dan barplot

data_cleaner.py adalah kode python yang saya buat untuk merapikan data

Saya menggunakan R dan Python untuk pemrosesan data